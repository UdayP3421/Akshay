package com.bookstore.models;

public class Order {
    private int orderId;
    private int userId;
    private double total;
    private String shippingAddress;

    public Order(int userId, double total, String shippingAddress) {
        this.userId = userId;
        this.total = total;
        this.shippingAddress = shippingAddress;
    }

    // Getters and Setters

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
}
