package com.bookstore.models;

import java.util.HashMap;
import java.util.Map;

public class Cart {
    private Map<Book, Integer> books = new HashMap<>();

    public void addBook(Book book) {
        books.put(book, books.getOrDefault(book, 0) + 1);
    }

    public double getTotalPrice() {
        return books.entrySet().stream().mapToDouble(e -> e.getKey().getPrice() * e.getValue()).sum();
    }

    // Getters and Setters

    public Map<Book, Integer> getBooks() {
        return books;
    }

    public void setBooks(Map<Book, Integer> books) {
        this.books = books;
    }
}
