package com.bookstore.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // PostgreSQL Database URL, Username, and Password
    private static final String URL = "jdbc:postgresql://localhost:5432/bookstore"; // Update "bookstore" to your actual database name
    private static final String USER = "postgres"; // Replace with your PostgreSQL username
    private static final String PASSWORD = "3421"; // Replace with your PostgreSQL password

    public static Connection getConnection() throws SQLException {
        try {
            // Load the PostgreSQL JDBC Driver (not always required with newer JDBC versions)
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        // Establish the connection to the database
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
