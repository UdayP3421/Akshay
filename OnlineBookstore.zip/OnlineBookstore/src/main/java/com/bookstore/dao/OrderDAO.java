package com.bookstore.dao;

import com.bookstore.models.Order;
import com.bookstore.models.Book;
import com.bookstore.models.Cart;
import java.sql.*;

public class OrderDAO {
    public int createOrder(Order order, Cart cart) {
        int orderId = 0;
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            String insertOrder = "INSERT INTO Orders (user_id, total, shipping_address) VALUES (?, ?, ?)";
            PreparedStatement psOrder = conn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS);
            psOrder.setInt(1, order.getUserId());
            psOrder.setDouble(2, order.getTotal());
            psOrder.setString(3, order.getShippingAddress());
            psOrder.executeUpdate();

            ResultSet rsOrder = psOrder.getGeneratedKeys();
            if (rsOrder.next()) {
                orderId = rsOrder.getInt(1);
            }

            String insertOrderItems = "INSERT INTO OrderItems (order_id, book_id, quantity) VALUES (?, ?, ?)";
            PreparedStatement psOrderItems = conn.prepareStatement(insertOrderItems);
            for (Book book : cart.getBooks().keySet()) {
                psOrderItems.setInt(1, orderId);
                psOrderItems.setInt(2, book.getId());
                psOrderItems.setInt(3, cart.getBooks().get(book));
                psOrderItems.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderId;
    }
}
