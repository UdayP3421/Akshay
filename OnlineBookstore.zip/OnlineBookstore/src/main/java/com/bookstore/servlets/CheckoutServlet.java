package com.bookstore.servlets;

import com.bookstore.dao.OrderDAO;
import com.bookstore.models.Cart;
import com.bookstore.models.Order;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart != null && !cart.getBooks().isEmpty()) {
            String shippingAddress = request.getParameter("shippingAddress");
            int userId = 1; // Assume user ID is 1 for now
            double total = cart.getTotalPrice();

            Order order = new Order(userId, total, shippingAddress);
            orderDAO.createOrder(order, cart);

            session.removeAttribute("cart");
            response.sendRedirect("orderConfirmation.jsp");
        } else {
            response.sendRedirect("cart.jsp");
        }
    }
}
